#!/usr/bin/env python3
"""CPU scheduling simulator for FCFS, SJF, SRTF, RR and preemptive Priority."""
from dataclasses import dataclass
from collections import deque
import argparse
from pathlib import Path


@dataclass
class Process:
    pid: str
    arrival: int
    burst: int
    priority: int


def pid_number(pid):
    digits = "".join(ch for ch in pid if ch.isdigit())
    return int(digits) if digits else 0


def process_key(p):
    return (p.arrival, pid_number(p.pid), p.pid)


def load_processes(filename):
    processes = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) != 4:
                raise ValueError(f"Ожидалось 4 поля PID arrival burst priority: {line}")
            pid, arrival, burst, priority = parts
            p = Process(pid, int(arrival), int(burst), int(priority))
            if p.arrival < 0 or p.burst <= 0:
                raise ValueError(f"Некорректные arrival/burst: {line}")
            processes.append(p)
    if not processes:
        raise ValueError(f"В файле {filename} нет процессов")
    if len({p.pid for p in processes}) != len(processes):
        raise ValueError("PID должны быть уникальными")
    return sorted(processes, key=process_key)


def merge_interval(intervals, pid, start, end):
    if end <= start:
        return
    if intervals and intervals[-1][0] == pid and intervals[-1][2] == start:
        old_pid, old_start, _ = intervals[-1]
        intervals[-1] = (old_pid, old_start, end)
    else:
        intervals.append((pid, start, end))


def fcfs(processes):
    time = 0
    intervals = []
    for p in sorted(processes, key=process_key):
        if time < p.arrival:
            time = p.arrival
        start = time
        time += p.burst
        merge_interval(intervals, p.pid, start, time)
    return intervals


def sjf(processes):
    """Non-preemptive SJF; ties: earlier arrival, then numeric PID."""
    remaining = {p.pid: p.burst for p in processes}
    by_pid = {p.pid: p for p in processes}
    completed = set()
    intervals = []
    time = 0
    while len(completed) < len(processes):
        ready = [p for p in processes if p.pid not in completed and p.arrival <= time]
        if not ready:
            time = min(p.arrival for p in processes if p.pid not in completed)
            ready = [p for p in processes if p.pid not in completed and p.arrival <= time]
        p = min(ready, key=lambda x: (x.burst, x.arrival, pid_number(x.pid), x.pid))
        start = time
        time += p.burst
        merge_interval(intervals, p.pid, start, time)
        completed.add(p.pid)
    return intervals


def srtf(processes):
    """Preemptive shortest remaining time first, simulated one time unit at a time."""
    remaining = {p.pid: p.burst for p in processes}
    by_pid = {p.pid: p for p in processes}
    done = set()
    intervals = []
    time = 0
    while len(done) < len(processes):
        ready = [p for p in processes if p.pid not in done and p.arrival <= time and remaining[p.pid] > 0]
        if not ready:
            time = min(p.arrival for p in processes if p.pid not in done and remaining[p.pid] > 0)
            ready = [p for p in processes if p.pid not in done and p.arrival <= time and remaining[p.pid] > 0]
        p = min(ready, key=lambda x: (remaining[x.pid], x.arrival, pid_number(x.pid), x.pid))
        merge_interval(intervals, p.pid, time, time + 1)
        remaining[p.pid] -= 1
        time += 1
        if remaining[p.pid] == 0:
            done.add(p.pid)
    return intervals


def rr(processes, quantum=3):
    """Round Robin. New arrivals at a quantum boundary enter before requeued process."""
    if quantum <= 0:
        raise ValueError("quantum должен быть положительным")
    ordered = sorted(processes, key=process_key)
    remaining = {p.pid: p.burst for p in ordered}
    by_pid = {p.pid: p for p in ordered}
    ready = deque()
    intervals = []
    time = 0
    next_idx = 0
    completed = set()

    while len(completed) < len(ordered):
        while next_idx < len(ordered) and ordered[next_idx].arrival <= time:
            ready.append(ordered[next_idx].pid)
            next_idx += 1
        if not ready:
            if next_idx < len(ordered):
                time = max(time, ordered[next_idx].arrival)
                continue
            break

        pid = ready.popleft()
        start = time
        run_for = min(quantum, remaining[pid])
        end = time + run_for
        # Process arrivals strictly before or at the end are enqueued before the
        # running process is returned to the tail.
        while next_idx < len(ordered) and ordered[next_idx].arrival < end:
            ready.append(ordered[next_idx].pid)
            next_idx += 1
        remaining[pid] -= run_for
        time = end
        merge_interval(intervals, pid, start, end)
        while next_idx < len(ordered) and ordered[next_idx].arrival <= time:
            ready.append(ordered[next_idx].pid)
            next_idx += 1
        if remaining[pid] > 0:
            ready.append(pid)
        else:
            completed.add(pid)
    return intervals


def priority_preemptive(processes):
    """Preemptive priority; smaller priority number is higher priority."""
    remaining = {p.pid: p.burst for p in processes}
    done = set()
    intervals = []
    time = 0
    while len(done) < len(processes):
        ready = [p for p in processes if p.pid not in done and p.arrival <= time and remaining[p.pid] > 0]
        if not ready:
            time = min(p.arrival for p in processes if p.pid not in done and remaining[p.pid] > 0)
            ready = [p for p in processes if p.pid not in done and p.arrival <= time and remaining[p.pid] > 0]
        p = min(ready, key=lambda x: (x.priority, x.arrival, pid_number(x.pid), x.pid))
        merge_interval(intervals, p.pid, time, time + 1)
        remaining[p.pid] -= 1
        time += 1
        if remaining[p.pid] == 0:
            done.add(p.pid)
    return intervals


ALGORITHMS = {
    "fcfs": fcfs,
    "sjf": sjf,
    "srtf": srtf,
    "rr": rr,
    "priority": priority_preemptive,
}


def calculate_metrics(processes, intervals):
    stats = {}
    for p in processes:
        own = [(start, end) for pid, start, end in intervals if pid == p.pid]
        if not own:
            raise ValueError(f"Для {p.pid} нет интервалов выполнения")
        completion = max(end for _, end in own)
        first_start = min(start for start, _ in own)
        turnaround = completion - p.arrival
        waiting = turnaround - p.burst
        response = first_start - p.arrival
        stats[p.pid] = {
            "arrival": p.arrival,
            "burst": p.burst,
            "priority": p.priority,
            "completion": completion,
            "turnaround": turnaround,
            "waiting": waiting,
            "response": response,
        }
    n = len(processes)
    averages = {
        key: sum(row[key] for row in stats.values()) / n
        for key in ("waiting", "turnaround", "response")
    }
    return stats, averages


def gantt_text(intervals):
    if not intervals:
        return "(нет интервалов)"
    pieces = [f"{start} --{pid}--> {end}" for pid, start, end in intervals]
    return " | ".join(pieces)


def main():
    parser = argparse.ArgumentParser(description="CPU scheduling simulator")
    parser.add_argument("--algo", choices=ALGORITHMS.keys(), required=True)
    parser.add_argument("--quantum", type=int, default=3, help="квант RR (по умолчанию 3)")
    parser.add_argument("input_file")
    args = parser.parse_args()

    processes = load_processes(args.input_file)
    if args.algo == "rr":
        intervals = rr(processes, args.quantum)
    else:
        intervals = ALGORITHMS[args.algo](processes)

    stats, averages = calculate_metrics(processes, intervals)
    print(f"Алгоритм: {args.algo.upper()}" + (f", quantum={args.quantum}" if args.algo == "rr" else ""))
    print("Диаграмма Ганта:")
    print(gantt_text(intervals))
    print("\nМетрики по процессам:")
    print(f"{'PID':<6}{'Wait':>8}{'Turnaround':>13}{'Response':>11}{'Completion':>12}")
    for p in processes:
        row = stats[p.pid]
        print(f"{p.pid:<6}{row['waiting']:>8}{row['turnaround']:>13}{row['response']:>11}{row['completion']:>12}")
    print("\nСредние метрики:")
    for key, value in averages.items():
        print(f"{key}: {value:.2f}")


if __name__ == "__main__":
    main()
