#!/usr/bin/env bash

set -u

total=0
max_errors=-1
max_file=""

for f in data/*.log; do
    [[ -f "$f" ]] || continue

    count=$(grep -c "ERROR" "$f" || true)

    total=$((total + count))

    if (( count > max_errors )); then
        max_errors=$count
        max_file=$f
    fi

    printf '%s: %s\n' "$f" "$count"
done

printf '\nTotal ERROR lines: %s\n' "$total"

if [[ -n "$max_file" ]]; then
    printf 'File with most errors: %s (%s)\n' \
        "$max_file" "$max_errors"
else
    printf 'No log files found.\n'
fi
